<?php include "includes/header.php" ?>
<?php include "includes/db.php" ?>

    <!-- Navigation -->
   
    <?php include "includes/navigation.php" ?>
    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">

                <h1 class="page-header">
                    Page Heading
                    <small>Secondary Text</small>
                </h1>

    <?php
    if(isset($_GET['p_id'])){
        $the_post_id = $_GET['p_id'];
        $the_post_author = $_GET['author'];
    }
    
    
    $myQuery = "SELECT * FROM posts WHERE post_user = '{$the_post_author}' ";
    $runQuery = mysqli_query($connection,$myQuery);

    while ($myData = mysqli_fetch_array($runQuery)) {
        $post_title = $myData['post_title'];
        $post_author = $myData['post_user'];
        $post_date = $myData['post_date'];
        $post_image = $myData['post_image'];
        $post_content = $myData['post_content'];
        
        
        
        ?>
         <!-- First Blog Post -->
         <h2>
                    <a href="#"><?php echo $post_title?></a>
                </h2>
                <p class="lead">
                    All posts by <?php echo $post_author?>
                </p>
                <p><span class="glyphicon glyphicon-time"></span><?php echo $post_date?></p>
                <hr>
                <img class="img-responsive"  src="images/<?php echo $post_image?>" alt="No image found">
                <hr>
                <p><?php echo $post_content?></p>
                <hr>
    
    <?php } ?>


               

            
             <!-- Blog Comments -->

<?php
    if(isset($_POST['create_comment'])){
        $the_post_id = $_GET['p_id'];
        $comment_author = $_POST['comment_author'];
        $comment_email = $_POST['comment_email'];
        $comment_content = $_POST['comment_content'];
        
        if(!empty($comment_author) && !empty($comment_email)&& !empty($comment_content)){
        $comment_Query = "INSERT INTO comments (comment_post_id, comment_author, comment_email, comment_content, comment_status, comment_date) VALUES ({$the_post_id}, '{$comment_author}', '{$comment_email}', '{$comment_content}', 'Unapproved', now())";
        $run_Comment_Query = mysqli_query($connection,$comment_Query);
        if(!$run_Comment_Query){
            die("QUERY FAILED" . mysqli_error($connection));
        }

        $comment_Count_Query = "UPDATE posts SET post_comment_count = post_comment_count + 1 WHERE post_id = {$the_post_id}";
        $run_Comment_Count_runQuery = mysqli_query($connection,$comment_Count_Query);
    }else {
        echo "<script>alert('Field can not be empty.')</script>";
    }
    }


?>

            </div>

            <!-- Blog Sidebar Widgets Column -->
            <?php include "includes/sidebar.php" ?>
            </div>
        <!-- /.row -->

        <hr>


        <?php include "includes/footer.php" ?>