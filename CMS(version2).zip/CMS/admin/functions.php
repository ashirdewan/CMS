<?php

function users_online(){

    if (isset($_GET['onlineusers'])) {
    global $connection;
    if (!$connection) {
        session_start();
        include("../includes/db.php");
    $session = session_id();
    $time = time();
    $time_out_in_seconds = 10;
    $time_out = $time - $time_out_in_seconds;


    $query = "SELECT * FROM users_online WHERE session ='$session'";
    $send_query = mysqli_query($connection, $query);
    $count =  mysqli_num_rows($send_query);

    if ($count == NULL) {
    mysqli_query($connection, "INSERT INTO users_online(session, time) VALUES('$session', $time)");

    }else {
    mysqli_query($connection, "UPDATE users_online SET time = '$time' WHERE session = '$session'");
    }

    $users_online_query =   mysqli_query($connection, "SELECT * FROM users_online WHERE time > '$time_out'");
    echo $count_users = mysqli_num_rows($users_online_query);
    }


}// get request isset
}

users_online();

function confirm_Query($result){
    global $connection;
     if(!$result){
        die("QUERY FAILED. " . mysqli_error($connection));
    }
}

function insert_Category(){
global $connection;
    if(isset($_POST['submit'])){
    $cat_title = $_POST['cat_title'];
    if($cat_title == "" || empty($cat_title)){
    echo"<h3>This Field should not be empty.</h3>";
    }else{
    $add_Category_Query = "INSERT INTO categories(cat_title) VALUES ('{$cat_title}')";
    $run_Add_Category_Query = mysqli_query($connection,$add_Category_Query);
    if(!$run_Add_Category_Query){
    die('QUERY FAILED'. mysqli_error($connection));
            }
        }
    }
}



function show_All_Category(){
global $connection;
    
    $myQuery = "SELECT * FROM categories";
    $runQuery = mysqli_query($connection,$myQuery);

    while ($myData = mysqli_fetch_array($runQuery)) {
    $cat_id=$myData['cat_id'];
    $cat_title=$myData['cat_title'];
    echo "<tr>";
    echo "<td>{$cat_id}</td>";
    echo "<td>{$cat_title}</td>";
    echo "<td><a href='categories.php?Delete={$cat_id}'>Delete</a></td>";
    echo "<td><a href='categories.php?Edit={$cat_id}'>Edit</a></td>";
    echo "<tr>";
    }
 
}




function delete_Category(){
global $connection;
    
    if(isset($_GET['Delete'])){
    $cat_id = $_GET['Delete'];
    $delete_Query = "DELETE FROM categories WHERE cat_id = {$cat_id}";
    $run_Delete_Query = mysqli_query($connection,$delete_Query);
    header("location:categories.php");
    
}                                    
 
}




?>