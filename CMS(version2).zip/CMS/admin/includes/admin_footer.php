
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <!-- link for ckeditor -->
    <script src="js/script.js"></script>
    <!-- link for checkbox -->
    <script src="js/checkbox.js"></script>
    <!-- link for loader -->
    <script src="js/loader.js"></script>
    <!-- link for users_online -->
    <script src="js/users_online.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
