<?php
if(isset($_GET['edit_user'])){
 $the_user_id = $_GET['edit_user'];

 $show_All_Users_Query = "SELECT * FROM users WHERE user_id = {$the_user_id}";
 $show_All_Users_runQuery = mysqli_query($connection,$show_All_Users_Query);

 while ($user_Info = mysqli_fetch_array($show_All_Users_runQuery)) {
     $user_id = $user_Info['user_id'];
     $username = $user_Info['username'];
     $user_password = $user_Info['user_password'];
     $user_firstname = $user_Info['user_firstname'];
     $user_lastname = $user_Info['user_lastname'];
     $user_email = $user_Info['user_email'];
     $user_image = $user_Info['user_image'];
     $user_role = $user_Info['user_role'];
}

?>





<?php

if(isset($_POST['edit_user'])){
    $user_firstname = $_POST['user_firstname'];
    $user_lastname = $_POST['user_lastname'];
    $user_role = $_POST['user_role'];
    $username = $_POST['username'];
    
    // $post_image = $_FILES['image']['name'];
    // $post_image_temp = $_FILES['image']['tmp_name'];
    
    $user_email = $_POST['user_email'];
    $user_password = $_POST['user_password'];
    // $post_date = date('d-m-y');
 
    
    
//     move_uploaded_file($post_image_temp,"../images/$post_image");
    if (!empty($user_password)) {
        $query_password = "SELECT user_password FROM users WHERE user_id = $the_user_id ";
        $run_query_password  = mysqli_query($connection, $query_password);
        $row = mysqli_fetch_array($run_query_password);
        $db_user_password = $row['user_password'];

        if ($db_user_password != $user_password) {
            $hashed_password = password_hash($user_password, PASSWORD_BCRYPT, array('cost' => 10));
        }

        $update_User_Query = "UPDATE users SET user_firstname='{$user_firstname}', user_lastname='{$user_lastname}', user_role='{$user_role}', username='{$username}', user_email='{$user_email}', user_password='{$hashed_password}' WHERE user_id={$the_user_id} ";
    
        $run_Update_User_Query = mysqli_query($connection,$update_User_Query);
        
        confirm_Query($run_Update_User_Query);
        echo "<p class='bg-success'>User Updated:" . " " . "<a href='./users.php'>View Users?</a></p>";
    
    }    
   
    
   
}

}else {
    header("Location:index.php");
}
?>
  

  
   <form action="" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="Firstname">Firstname</label>
        <input type="text" value="<?php echo $user_firstname;?>" class="form-control" name="user_firstname">
    </div>

    <div class="form-group">
        <label for="Lastname">Lastname</label>
        <input type="text" value="<?php echo $user_lastname;?>" class="form-control" name="user_lastname">
    </div>
    
    
    <div class="form-group">
    <label for="user_role">User Role</label><br>
    <select name="user_role" id="user_role">
    <option value="<?php echo $user_role;?>"><?php echo $user_role;?></option>
<?php
if($user_role == 'admin'){
    echo "<option value='subscriber'>subscriber</option>";
}else{
    echo "<option value='admin'>admin</option>";
}

?>
        
        
    </select>
    </div>
    
    
    <div class="form-group">
        <label for="username">Username</label>
        <input type="text" value="<?php echo $username;?>" class="form-control" name="username">
    </div>
    
    
    <div class="form-group">
        <label for="user_email">Email</label>
        <input type="email" value="<?php echo $user_email;?>" class="form-control" name="user_email">
    </div> 
    
    
  <!--  <div class="form-group">
        <label for="post_image">Post Image</label>
        <input type="file" name="image">
    </div>
    !-->
    
    
    <div class="form-group">
        <label for="user_password">Password</label>
        <input type="password" class="form-control" name="user_password">
    </div>

    
    
    <div class="form-group">
        <input type="submit" class="btn btn-primary" name="edit_user" value="Update User">   
    </div>
</form>
