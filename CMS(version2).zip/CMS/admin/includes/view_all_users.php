<?php
if(isset($_GET['delete'])){

    if (isset($_SESSION['user_role'])) {
        
   if (isset($_SESSION['user_role']) == 'admin') {
       
    $the_user_id = mysqli_real_escape_string($connection, $_GET['delete']);
    $delete_User_Query = "DELETE FROM users WHERE user_id = {$the_user_id}";
    $delete_User_runQuery = mysqli_query($connection,$delete_User_Query);
    header("location:users.php");
            }
        }
    }

if(isset($_GET['change_to_admin'])){
    $the_user_id = $_GET['change_to_admin'];
    $changetoadmin_User_Query = "UPDATE users SET user_role = 'admin' WHERE user_id = {$the_user_id}";
    $changetoadmin_User_runQuery = mysqli_query($connection,$changetoadmin_User_Query);
    header("location:users.php");
}


if(isset($_GET['change_to_subscriber'])){
    $the_user_id = $_GET['change_to_subscriber'];
    $changetosub_User_Query = "UPDATE users SET user_role = 'subscriber' WHERE user_id = {$the_user_id}";
    $changetosub_User_runQuery = mysqli_query($connection,$changetosub_User_Query);
    header("location:users.php");
}

?>   
                           
                           <table class="table  table-bordered table-hover">
                            <thead>
                                <tr>
                                    <td>Id</td>
                                    <td>Username</td>
                                    <td>Firstname</td>
                                    <td>Lastname</td>
                                    <td>Email</td>
                                    <td>Current Role</td>
                                    <td colspan="2">Set Role</td>
                                    <td colspan="2">Operations</td>
                                </tr>
                            </thead>
                            <tbody>
                                
                                   
<?php
    $show_All_Users_Query = "SELECT * FROM users";
    $show_All_Users_runQuery = mysqli_query($connection,$show_All_Users_Query);

    while ($user_Info = mysqli_fetch_array($show_All_Users_runQuery)) {
        $user_id = $user_Info['user_id'];
        $username = $user_Info['username'];
        $user_password = $user_Info['user_password'];
        $user_firstname = $user_Info['user_firstname'];
        $user_lastname = $user_Info['user_lastname'];
        $user_email = $user_Info['user_email'];
        $user_image = $user_Info['user_image'];
        $user_role = $user_Info['user_role'];
        
        
        echo "<tr>";
        echo "<td>{$user_id}</td>";
        echo "<td>{$username}</td>";
        echo "<td>{$user_firstname}</td>";
         
        
/*        $Query = "SELECT * FROM categories WHERE cat_id = {$post_category_id} ";
        $runQuery = mysqli_query($connection,$Query);
        while($myData = mysqli_fetch_array($runQuery)) {    
        $cat_title=$myData['cat_title'];
        
        }
        echo "<td>{$cat_title}</td>";*/
        
 
        
        echo "<td>{$user_lastname}</td>";
        echo "<td>{$user_email}</td>";


    /*    $Query = "SELECT * FROM posts WHERE  post_id = $comment_post_id ";
        $runQuery = mysqli_query($connection,$Query);
        while ($myData = mysqli_fetch_array($runQuery)) {
            $post_id = $myData['post_id'];
            $post_title = $myData['post_title'];
            
            echo "<td><a href='../post.php?p_id={$post_id}'>{$post_title}</a></td>";    
        }
       */



        echo "<td>{$user_role}</td>";
      
        echo "<td><a href='users.php?change_to_admin={$user_id}'>Admin</a></td>";
        echo "<td><a href='users.php?change_to_subscriber={$user_id}'>Subscriber</a></td>";
        echo "<td><a href='users.php?source=edit_user&edit_user={$user_id}'>Edit</a></td>";
        echo "<td><a href='users.php?delete={$user_id}'>Delete</a></td>";
        echo "</tr>";
    }
                                
                                
?>
                                   
                                
                            </tbody>
                        </table>
                    