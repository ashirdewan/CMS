<?php
if(isset($_GET['delete'])){
    $the_post_id = $_GET['delete'];
    $delete_Post_Query = "DELETE FROM posts WHERE post_id = {$the_post_id}";
    $delete_Post_runQuery = mysqli_query($connection,$delete_Post_Query);
    header("location:posts.php");
}

if(isset($_GET['reset'])){
    $the_views_post_id = $_GET['reset'];
    $view_Post_Query = "UPDATE posts SET post_views_count = 0 WHERE post_id = {$the_views_post_id}";
    $view_Post_runQuery = mysqli_query($connection,$view_Post_Query);
    header("location:posts.php");
}

?>   


<?php
if(isset($_POST['checkBoxArray'])){
    foreach ($_POST['checkBoxArray'] as $checkBoxValue) {
    $bulk_options = $_POST['bulk_options'];

    switch ($bulk_options) {
        case 'published':
            $Query = "UPDATE posts SET post_status = '{$bulk_options}' WHERE post_id = {$checkBoxValue} ";
            $updateToPublished = mysqli_query($connection, $Query);
            confirm_Query($updateToPublished);
            break;

        case 'draft':
            $Query = "UPDATE posts SET post_status = '{$bulk_options}' WHERE post_id = {$checkBoxValue} ";
            $updateToDraft = mysqli_query($connection, $Query);
            confirm_Query($updateToDraft);
            break;

        case 'delete':
            $Query = "DELETE FROM posts WHERE post_id = {$checkBoxValue} ";
            $selectedToDelete = mysqli_query($connection, $Query);
            confirm_Query($selectedToDelete);
            break;

        case 'clone':
            $Query = "SELECT * FROM posts WHERE post_id = {$checkBoxValue} ";
            $selectedToClone = mysqli_query($connection, $Query);
            confirm_Query($selectedToClone);
            while ($post_Info = mysqli_fetch_array($selectedToClone)) {
                $post_title = $post_Info['post_title'];
                $post_category_id = $post_Info['post_category_id'];
                $post_date = $post_Info['post_date'];
                $post_author = $post_Info['post_author'];
                $post_user = $post_Info['post_user'];
                $post_status = $post_Info['post_status'];
                $post_image = $post_Info['post_image'];
                $post_tags = $post_Info['post_tags'];
                $post_content = $post_Info['post_content'];
            }
            $add_Post_Query = "INSERT INTO posts(post_category_id, post_title, post_author, post_user, post_date, post_image, post_content, post_tags, post_status) VALUES ({$post_category_id}, '{$post_title}','{$post_author}', '{$post_user}', now(),'{$post_image}','{$post_content}','{$post_tags}','{$post_status}')";
            $run_Add_Post_Query = mysqli_query($connection,$add_Post_Query);            
            confirm_Query($run_Add_Post_Query);
            break;

        case 'reset':
            $Query = "UPDATE posts SET post_views_count = 0 WHERE post_id = {$checkBoxValue} ";
            $selectedToReset = mysqli_query($connection, $Query);
            confirm_Query($selectedToReset);
            break;
        
        default:
           echo "<h2>Please select one of the options.</h2>";
            break;
    }
    }
}

?>



<form action="" method="post">

<div class="bulkOptionContainer" class="col-xs-4">

    <select class="form-control" name="bulk_options" id="">
        <option value="">Select Option</option>
        <option value="published">Published</option>
        <option value="draft">Draft</option>
        <option value="delete">Delete</option>
        <option value="clone">Clone</option>
        <option value="reset">Reset Visited Post</option>
    </select>
<br>
<div class="col-xs-4">
<input type="submit" name="submit" class="btn btn-success" value="Apply">
<a href="posts.php?source=add_post" class="btn btn-primary">Add New</a><br><br>
</div>

</div>





                           <table class="table  table-bordered table-hover">
                            <thead>
                                <tr>
                                <td><input type="checkbox" name="" id="selectAllBoxes"></td>
                                    <td>Id</td>
                                    <td>Users</td>
                                    <td>Title</td>
                                    <td>Category</td>
                                    <td>Status</td>
                                    <td>Image</td>
                                    <td>Content</td>
                                    <td>Tags</td>
                                    <td>Comments</td>
                                    <td>Date</td>
                                    <td>View Post</td>
                                    <td colspan="2">Operations</td>
                                    <td>Post Visited</td>
                                </tr>
                            </thead>
                            <tbody>
                                
                                   
<?php
    $show_All_Post_Query = "SELECT * FROM posts ORDER BY post_id DESC";
    $show_All_Post_runQuery = mysqli_query($connection,$show_All_Post_Query);

    while ($post_Info = mysqli_fetch_array($show_All_Post_runQuery)) {
        $post_id = $post_Info['post_id'];
        $post_author = $post_Info['post_author'];
        $post_user = $post_Info['post_user'];
        $post_title = $post_Info['post_title'];
        $post_category_id = $post_Info['post_category_id'];
        $post_status = $post_Info['post_status'];
        $post_image = $post_Info['post_image'];
        $post_content = $post_Info['post_content'];
        $post_tags = $post_Info['post_tags'];
        $post_comment_count = $post_Info['post_comment_count'];
        $post_date = $post_Info['post_date'];
        $post_views_count = $post_Info['post_views_count'];
          
        echo "<tr>";

        ?>
        <td><input type="checkbox" class="checkBoxes" name="checkBoxArray[]" value="<?php echo $post_id; ?>"></td>
        <?php
        echo "<td>{$post_id}</td>";


        if (!empty($post_author)) {
            echo "<td>{$post_author}</td>";
        }
        elseif (!empty($post_user)) {
            echo "<td>{$post_user}</td>";
        }

        






        echo "<td>{$post_title}</td>";
        
        
        $Query = "SELECT * FROM categories WHERE cat_id = {$post_category_id} ";
        $runQuery = mysqli_query($connection,$Query);
        while($myData = mysqli_fetch_array($runQuery)) {    
        $cat_title=$myData['cat_title'];
        
        }
        echo "<td>{$cat_title}</td>";    
        echo "<td>{$post_status}</td>";
        echo "<td><img width='100' src='../images/{$post_image}' alt='image not found'></td>";
        echo "<td>{$post_content}</td>";
        echo "<td>{$post_tags}</td>";



        $query = "SELECT * FROM comments WHERE comment_post_id = $post_id";
        $send_comment_query = mysqli_query($connection, $query);
        // $row = mysqli_fetch_array($send_comment_query);
        // $comment_id = $row['comment_id'];
        $count_comments = mysqli_num_rows($send_comment_query);
 
        echo "<td><a href='post_comments.php?id=$post_id'>{$count_comments}</a></td>";






        echo "<td>{$post_date}</td>";
        echo "<td><a href='../post.php?p_id={$post_id}'>View Post</a></td>";
        echo "<td><a href='posts.php?source=edit_post&p_id={$post_id}'>Edit</a></td>";
        echo "<td><a onClick=\"javascript: return confirm('Are you sure to delete?');\" href='posts.php?delete={$post_id}'>Delete</a></td>";
        echo "<td>{$post_views_count}<br/><a href='posts.php?reset={$post_id}'>Reset</a></td>";
        echo "</tr>";
    }
                                
                                
?>
                                   
                                
                            </tbody>
                        </table>
                        </form>           