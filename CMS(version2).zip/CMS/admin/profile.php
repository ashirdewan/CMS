<?php include "includes/admin_header.php"; ?>

<?php
if(isset($_SESSION['username'])){

    $username = $_SESSION['username'];

    $query = "SELECT * FROM users WHERE username ='{$username}' ";
    $select_user_profile_query = mysqli_query($connection, $query);

    while ($result = mysqli_fetch_assoc($select_user_profile_query)) {
        $user_id = $result['user_id'];
        $username = $result['username'];
        $user_password = $result['user_password'];
        $user_firstname = $result['user_firstname'];
        $user_lastname = $result['user_lastname'];
        $user_email = $result['user_email'];
        $user_image = $result['user_image'];
        $user_role = $result['user_role'];
    }?>
}

<?php

if(isset($_POST['edit_user'])){
    $user_firstname = $_POST['user_firstname'];
    $user_lastname = $_POST['user_lastname'];
    $username = $_POST['username'];
    
    // $post_image = $_FILES['image']['name'];
    // $post_image_temp = $_FILES['image']['tmp_name'];
    
    $user_email = $_POST['user_email'];
    $user_password = $_POST['user_password'];
    // $post_date = date('d-m-y');
 
    
    
//     move_uploaded_file($post_image_temp,"../images/$post_image");
    if (!empty($user_password)) {
        $query_password = "SELECT user_password FROM users WHERE user_id = $user_id ";
        $run_query_password  = mysqli_query($connection, $query_password);
        $row = mysqli_fetch_array($run_query_password);
        $db_user_password = $row['user_password'];

        if ($db_user_password != $user_password) {
            $hashed_password = password_hash($user_password, PASSWORD_BCRYPT, array('cost' => 10));
        }

        $update_User_Query = "UPDATE users SET user_firstname='{$user_firstname}', user_lastname='{$user_lastname}', user_role='{$user_role}', username='{$username}', user_email='{$user_email}', user_password='{$hashed_password}' WHERE user_id={$user_id} ";
    
        $run_Update_User_Query = mysqli_query($connection,$update_User_Query);
        
        confirm_Query($run_Update_User_Query);
        echo "<p class='bg-success'>Profile Updated:" . " " . "<a href='./users.php'>View Users?</a></p>";
    }        
   
}

}
?>


    <div id="wrapper">

        <!-- Navigation -->
<?php include "includes/admin_navigation.php"; ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        
                         <h1 class="page-header">
                            Welcome to Admin
                            <small>Author</small>
                        </h1>
                        
 <form action="" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="Firstname">Firstname</label>
        <input type="text" value="<?php echo $user_firstname;?>" class="form-control" name="user_firstname">
    </div>

    <div class="form-group">
        <label for="Lastname">Lastname</label>
        <input type="text" value="<?php echo $user_lastname;?>" class="form-control" name="user_lastname">
    </div>
        
    <div class="form-group">
        <label for="username">Username</label>
        <input type="text" value="<?php echo $username;?>" class="form-control" name="username">
    </div>
    
    
    <div class="form-group">
        <label for="user_email">Email</label>
        <input type="email" value="<?php echo $user_email;?>" class="form-control" name="user_email">
    </div> 
    
    
  <!--  <div class="form-group">
        <label for="post_image">Post Image</label>
        <input type="file" name="image">
    </div>
    !-->
    
    
    <div class="form-group">
        <label for="user_password">Password</label>
        <input type="password" autocomplete="off" class="form-control" name="user_password">
    </div>

    
    
    <div class="form-group">
        <input type="submit" class="btn btn-primary" name="edit_user" value="Update Profile">   
    </div>
</form>
                        
                        
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

<?php include "includes/admin_footer.php"; ?>