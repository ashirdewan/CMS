<?php include "includes/admin_header.php"; ?>

    <div id="wrapper">

        <!-- Navigation -->
<?php include "includes/admin_navigation.php"; ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome to Admin
                            <small>Author</small>
                        </h1>
                           
                        
                        
                        
                        <!-- /#Add Category Form Start -->
                        <div class="col-xs-6">
                            
                            
<?php insert_Category(); ?>
                            
                        <form action="" method="post">
                            <label for="cat-title">Add Category</label>
                            <div class="form-froup">
                                <input class="form-control" type="text" name="cat_title">
                            </div> <br>
                            <div class="form-froup">
                                <input class="btn btn-primary" type="submit" name="submit" value="Add Category">
                            </div>
                        </form>
                        
                        
<?php
if(isset($_GET['Edit'])){
    $cat_id = $_GET['Edit'];
    include "includes/update_categories.php";
}

?>
                        </div>
                        
 
                       

                        <!-- /#Add Category Form Ends -->
                           
                        
                        <div class="col-xs-6">                       
                            <table class="table  table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Category Title</th>
                                        <th colspan="2">Operations</th>
                                    </tr>
                                </thead>
                                <tbody>

                                   
<?php show_All_Category(); ?>

<?php delete_Category(); ?> 
                                                                                                                                   
                                </tbody>
                            </table>
                        
                        </div>
                        
                        
                        
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

<?php include "includes/admin_footer.php"; ?>