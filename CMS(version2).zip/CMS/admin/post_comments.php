<?php include "includes/admin_header.php"; ?>

    <div id="wrapper">

        <!-- Navigation -->
<?php include "includes/admin_navigation.php"; ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        
                         <h1 class="page-header">
                            Welcome to Admin
                            <small>Author</small>
                        </h1>

<?php
if(isset($_GET['delete'])){
    $the_comment_id = $_GET['delete'];
    $delete_Comment_Query = "DELETE FROM comments WHERE comment_id = {$the_comment_id}";
    $delete_Comment_runQuery = mysqli_query($connection,$delete_Comment_Query);
    header("location:post_comments.php?id=". $_GET['id']."");
}


if(isset($_GET['approve'])){
    $the_comment_id = $_GET['approve'];
    $approve_Comment_Query = "UPDATE comments SET comment_status ='Approved' WHERE comment_id = {$the_comment_id}";
    $approve_Comment_runQuery = mysqli_query($connection,$approve_Comment_Query);
    header("location:comments.php");
}


if(isset($_GET['unapprove'])){
    $the_comment_id = $_GET['unapprove'];
    $unapprove_Comment_Query = "UPDATE comments SET comment_status ='Unapproved' WHERE comment_id = {$the_comment_id}";
    $unapprove_Comment_runQuery = mysqli_query($connection,$unapprove_Comment_Query);
    header("location:comments.php");
}

?>   
                           
                           <table class="table  table-bordered table-hover">
                            <thead>
                                <tr>
                                    <td>Id</td>
                                    <td>Author</td>
                                    <td>Comment</td>
                                    <td>Email</td>
                                    <td>Status</td>
                                    <td>In Response to</td>
                                    <td>Date</td>
                                    <td>Approve</td>
                                    <td>Unapprove</td>
                                    <td colspan="2">Operations</td>
                                </tr>
                            </thead>
                            <tbody>
                                
                                   
<?php
    $show_All_Comments_Query = "SELECT * FROM comments WHERE comment_post_id =" . mysqli_real_escape_string($connection, $_GET['id']). " ";
    $show_All_Comments_runQuery = mysqli_query($connection,$show_All_Comments_Query);

    while ($post_Info = mysqli_fetch_array($show_All_Comments_runQuery)) {
        $comment_id = $post_Info['comment_id'];
        $comment_post_id = $post_Info['comment_post_id'];
        $comment_author = $post_Info['comment_author'];
        $comment_email = $post_Info['comment_email'];
        $comment_content = $post_Info['comment_content'];
        $comment_status = $post_Info['comment_status'];
        $comment_content = $post_Info['comment_content'];
        $comment_date = $post_Info['comment_date'];
        
        
        echo "<tr>";
        echo "<td>{$comment_id}</td>";
        echo "<td>{$comment_author}</td>";
        echo "<td>{$comment_content}</td>";
         
        
/*        $Query = "SELECT * FROM categories WHERE cat_id = {$post_category_id} ";
        $runQuery = mysqli_query($connection,$Query);
        while($myData = mysqli_fetch_array($runQuery)) {    
        $cat_title=$myData['cat_title'];
        
        }
        echo "<td>{$cat_title}</td>";*/
        
 
        
        echo "<td>{$comment_email}</td>";
        echo "<td>{$comment_status}</td>";


        $Query = "SELECT * FROM posts WHERE  post_id = $comment_post_id ";
        $runQuery = mysqli_query($connection,$Query);
        while ($myData = mysqli_fetch_array($runQuery)) {
            $post_id = $myData['post_id'];
            $post_title = $myData['post_title'];
            
            echo "<td><a href='../post.php?p_id={$post_id}'>{$post_title}</a></td>";    
        }
       



        echo "<td>{$comment_date}</td>";
      
        echo "<td><a href='comments.php?approve={$comment_id}'>Approve</a></td>";
        echo "<td><a href='comments.php?unapprove={$comment_id}'>Unapprove</a></td>";
        echo "<td><a href='post_comments.php?delete={$comment_id}&id=".$_GET['id']."'>Delete</a></td>";
        echo "</tr>";
    }
                                
                                
?>
                                   
                                
                            </tbody>
                        </table>
                                    
                        </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

<?php include "includes/admin_footer.php"; ?>