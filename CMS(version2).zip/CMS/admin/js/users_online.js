function loadUserOnline(){

    $.get("functions.php?onlineusers=result" ,function(data){
        $(".usersonline").text(data);


    });
}
setInterval(function(){
    loadUserOnline();

},500);
