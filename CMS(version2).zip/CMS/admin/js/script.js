$(document).ready(function(){
//EDITOR CKEDITOR
    ClassicEditor
    .create( document.querySelector( '#editor' ) )
    .catch( error => {
    console.error( error );
    } );    
});


    