                       <!-- /#Edit Category Form Start -->
                          <form action="" method="post">
                           <label for="cat-title">Edit Category</label> 
                            <div class="form-froup">
<?php

//Edit Category

if(isset($_GET['Edit'])){
$cat_id = $_GET['Edit'];
$edit_Query = "SELECT cat_title FROM categories WHERE cat_id = {$cat_id}";
$run_Edit_Query = mysqli_query($connection,$edit_Query);
if(!$run_Edit_Query){
die("QUERY FAILED" . mysqli_error($connection));
}else{
while ($myData = mysqli_fetch_array($run_Edit_Query)) {    
$cat_title=$myData['cat_title'];
?>
                        
                           
                            <input value="<?php echo "{$cat_title}";?>"                                   class="form-control" type="text" name="cat_title">    
                            
<?php }
}

}                                    
?> 
                            
<?php ///////Update Query
if(isset($_POST['update_Category'])){
$the_cat_title = $_POST['cat_title'];
$update_Category_Query = "UPDATE categories SET cat_title = '{$the_cat_title}' WHERE cat_id = {$cat_id}";
$run_Update_Category_Query = mysqli_query($connection,$update_Category_Query);
    if(!$run_Update_Category_Query){
        die("QUERY FAILED" . mysqli_error($connection));
    }

} ?>      
                            
                            </div> <br>
                            <div class="form-froup">
                                <input class="btn btn-primary" type="submit" name="update_Category" value="Update Category">
                            </div>
                        </form>
                         <!-- /#Edit Category Form Ends -->