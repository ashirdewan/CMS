<?php
if(isset($_GET['p_id'])){
    $the_post_id = $_GET['p_id'];

    $show_All_Post_Data_Query = "SELECT * FROM posts WHERE post_id={$the_post_id}";
    $show_All_Post_runQuery = mysqli_query($connection,$show_All_Post_Data_Query);

    while ($post_Info = mysqli_fetch_array($show_All_Post_runQuery)) {
        $post_id = $post_Info['post_id'];
        $post_author = $post_Info['post_author'];
        $post_title = $post_Info['post_title'];
        $post_category_id = $post_Info['post_category_id'];
        $post_status = $post_Info['post_status'];
        $post_image = $post_Info['post_image'];
        $post_content = $post_Info['post_content'];
        $post_tags = $post_Info['post_tags'];
        $post_comment_count = $post_Info['post_comment_count'];
        $post_date = $post_Info['post_date'];
    }
}
if(isset($_POST['update_post'])){
    $post_author = $_POST['post_author'];
    $post_title = $_POST['post_title'];
    $post_category_id = $_POST['post_category'];
    $post_status = $_POST['post_status'];
    $post_image = $_FILES['image']['name'];
    $post_image_temp = $_FILES['image']['tmp_name'];
    $post_content = $_POST['post_content'];
    $post_tags = $_POST['post_tags'];
    
     
move_uploaded_file($post_image_temp,"../images/$post_image");
    
    if(empty($post_image)){
        $query = "SELECT post_image FROM posts WHERE post_id = $the_post_id ";
        $runQuery = mysqli_query($connection,$query);
        
        while($myData = mysqli_fetch_array($runQuery)){
            $post_image = $myData['post_image'];
        }
            
    }
    
    $myQuery = "UPDATE posts SET post_category_id='{$post_category_id}', post_title='{$post_title}', post_author='{$post_author}', post_date=now(), post_image='{$post_image}',post_content='{$post_content}', post_tags='{$post_tags}', post_status='{$post_status}' WHERE post_id={$the_post_id}";
    
    $update_post = mysqli_query($connection,$myQuery);
    confirm_Query($update_post);
}
   ?>

   
   <form action="" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="title">Post Title</label>
        <input value="<?php echo $post_title;?>" type="text" class="form-control" name="post_title">
    </div>
    
    
    <div class="form-group">
        <label for="post_category">Select Category</label><br>
        <select name="post_category" id="post_category">
        
<?php

$edit_Query = "SELECT * FROM categories;";
$run_Edit_Query = mysqli_query($connection,$edit_Query);
confirm_Query($run_Edit_Query);
while ($myData = mysqli_fetch_array($run_Edit_Query)) {    
    $cat_id=$myData['cat_id'];
    $cat_title=$myData['cat_title'];
    echo "<option value='{$cat_id}'>{$cat_title}</option>
";
}
?>
   </select>
    </div>
    
    
    <div class="form-group">
        <label for="title">Post Author</label>
        <input value="<?php echo $post_author;?>" type="text" class="form-control" name="post_author">
    </div>
    
    
    <div class="form-group">
        <label for="post_status">Post Status</label>
        <input value="<?php echo $post_status;?>" type="text" class="form-control" name="post_status">
    </div> 
    
    
    <div class="form-group">
        <label for="post_image">Post Image</label>
        <input type="file" name="image">
       <img width="100" src="../images/<?php echo $post_image;?>">
    </div>
    
    
    <div class="form-group">
        <label for="post_tags">Post Tags</label>
        <input value="<?php echo $post_tags;?>" type="text" class="form-control" name="post_tags">
    </div>
    
    
    <div class="form-group">
        <label for="post_content">Post Content</label>
        <textarea class="form-control" name="post_content" id="" cols="30" rows="10"><?php echo $post_content;?>
        </textarea>
    </div>
    
    
    <div class="form-group">
        <input type="submit" class="btn btn-primary" name="update_post" value="Update Post">   
    </div>
</form>
